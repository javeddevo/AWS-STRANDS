import boto3
from strands import Agent, tool
from strands.models import BedrockModel
from tools import (
    get_claim_request,
    get_policy_details,
    check_disease_coverage,
    get_claim_documents,
)

# ── Model Setup (AWS Bedrock Claude) ──────────────────────────────────────────

model = BedrockModel(
    model_id="anthropic.claude-3-5-sonnet-20241022-v2:0",
    region_name="us-east-1",
)

# ── Critic Agent ───────────────────────────────────────────────────────────────

_critic = Agent(
    model=model,
    system_prompt="""You are a strict insurance claim critic.
Your job is to cross-check all the details provided and find ANY issues, mismatches, or missing information.
Be thorough. Report every issue you find clearly.
End your response with either:
  CRITIC_PASS: <summary of what looks good>
  CRITIC_FAIL: <list of issues found>
""",
)

@tool
def critic_tool(details_to_review: str) -> str:
    """
    Cross-checks claim details and finds any issues or mismatches.
    Always call this BEFORE jury_tool.
    Pass all relevant claim/document details as input.
    """
    result = _critic(f"Please cross-check these details carefully:\n\n{details_to_review}")
    return str(result)


# ── Jury Agent ─────────────────────────────────────────────────────────────────

_jury = Agent(
    model=model,
    system_prompt="""You are the final insurance claim jury.
You receive the critic's review and make the final verdict.
You must respond with ONLY one of:
  VERDICT: APPROVED - <reason>
  VERDICT: REJECTED - <reason>
Be decisive. No ambiguity.
""",
)

@tool
def jury_tool(critic_review: str) -> str:
    """
    Takes critic's review and gives the final APPROVED or REJECTED verdict.
    Always call this AFTER critic_tool.
    Pass the full critic review as input.
    """
    result = _jury(f"Based on this critic review, give your final verdict:\n\n{critic_review}")
    return str(result)


# ── Adjudication Agent ─────────────────────────────────────────────────────────

adjudication_agent = Agent(
    name="adjudication_agent",
    model=model,
    system_prompt="""You are an Insurance Adjudication Agent.

Your job:
1. Call get_claim_request to read the incoming claim
2. Call get_policy_details with the policy_id to check if policy exists and is ACTIVE
3. Call check_disease_coverage with the disease to check if it is covered
4. If policy is inactive OR disease is not covered → immediately output ADJUDICATION_FAILED: <reason>
5. If all checks pass → call critic_tool with all the gathered details
6. Pass critic's response to jury_tool for final verdict
7. If jury says APPROVED → output ADJUDICATION_PASSED: <summary>
8. If jury says REJECTED → output ADJUDICATION_FAILED: <reason>

Be precise and systematic. Follow the steps in order.
""",
    tools=[get_claim_request, get_policy_details, check_disease_coverage, critic_tool, jury_tool],
)


# ── Document Checker Agent ─────────────────────────────────────────────────────

document_checker_agent = Agent(
    name="document_checker_agent",
    model=model,
    system_prompt="""You are an Insurance Document Verification Agent.

Your job:
1. Call get_claim_documents with the claim_id to fetch submitted documents
2. Check ALL of these:
   - Hospital is in approved network
   - Patient ID proof is verified and matches policy holder
   - Doctor is registered
   - Bills are NOT tampered
   - Diagnosis matches the claimed disease
   - All documents are present and verified
3. Pass all document details to critic_tool for cross-checking
4. Pass critic's response to jury_tool for final verdict
5. If jury says APPROVED → output DOCUMENT_VERIFIED: <summary>
6. If jury says REJECTED → output DOCUMENT_FAILED: <reason> (e.g. fake documents detected)

Be thorough. Any fake or missing document must result in rejection.
""",
    tools=[get_claim_documents, critic_tool, jury_tool],
)


# ── Approval Agent ─────────────────────────────────────────────────────────────

approval_agent = Agent(
    name="approval_agent",
    model=model,
    system_prompt="""You are the final Insurance Claim Approval Agent.

Your job:
1. You will receive the claim details including disease, bill amount, and coverage percentage
2. Calculate the approved amount:
   approved_amount = (coverage_percentage / 100) * bill_amount
3. Make sure approved_amount does not exceed max_coverage_amount from policy
4. Output a clear approval summary:

CLAIM APPROVED ✅
  Claim ID          : <claim_id>
  Patient Name      : <name>
  Disease           : <disease>
  Total Bill        : ₹<bill_amount>
  Coverage          : <coverage_percentage>%
  Approved Amount   : ₹<approved_amount>
  Remarks           : Payment will be processed within 5 business days.
""",
    tools=[],
)
