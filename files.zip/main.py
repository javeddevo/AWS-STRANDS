import json
from strands.multiagent import GraphBuilder
from strands.multiagent.graph import GraphState
from strands.multiagent.base import Status
from agents import adjudication_agent, document_checker_agent, approval_agent

# ── Conditional Edge Functions ─────────────────────────────────────────────────

def adjudication_passed(state: GraphState) -> bool:
    """
    Only move to document checker if adjudication PASSED.
    If policy is invalid or disease not covered → STOP here.
    """
    result = state.results.get("adjudication_agent")
    if not result or result.status != Status.COMPLETED:
        print("\n🛑 STOP: Adjudication did not complete.")
        return False

    result_text = str(result.result).upper()
    passed = "ADJUDICATION_PASSED" in result_text

    if not passed:
        print("\n🛑 STOP: Adjudication FAILED — Policy invalid or disease not covered.")
    else:
        print("\n✅ Adjudication PASSED — Moving to Document Checker.")

    return passed


def documents_verified(state: GraphState) -> bool:
    """
    Only move to approval if documents are verified.
    If documents are fake or missing → STOP here.
    """
    result = state.results.get("document_checker_agent")
    if not result or result.status != Status.COMPLETED:
        print("\n🛑 STOP: Document check did not complete.")
        return False

    result_text = str(result.result).upper()
    passed = "DOCUMENT_VERIFIED" in result_text

    if not passed:
        print("\n🛑 STOP: Document check FAILED — Fake or missing documents detected.")
    else:
        print("\n✅ Documents VERIFIED — Moving to Approval.")

    return passed


# ── Build the Graph ────────────────────────────────────────────────────────────

def build_claim_graph():
    builder = GraphBuilder()

    # Add all 3 agents as nodes
    builder.add_node(adjudication_agent,    "adjudication_agent")
    builder.add_node(document_checker_agent, "document_checker_agent")
    builder.add_node(approval_agent,         "approval_agent")

    # Conditional edges = STOP GATES
    builder.add_edge("adjudication_agent",    "document_checker_agent", condition=adjudication_passed)
    builder.add_edge("document_checker_agent", "approval_agent",         condition=documents_verified)

    # Entry point
    builder.set_entry_point("adjudication_agent")

    # Safety limits
    builder.set_execution_timeout(300)

    return builder.build()


# ── Run ────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":

    print("=" * 60)
    print("   🏥 INSURANCE PRE-CLAIM ADJUDICATION SYSTEM")
    print("=" * 60)

    # Load claim request to pass as initial context
    with open("mock_claim_request.json") as f:
        claim_data = json.load(f)

    claim_id = claim_data["claim_request"]["claim_id"]
    policy_id = claim_data["claim_request"]["policy_id"]
    disease   = claim_data["claim_request"]["disease"]
    bill      = claim_data["claim_request"]["estimated_bill_amount"]

    task = f"""
Process this insurance pre-claim:
  Claim ID   : {claim_id}
  Policy ID  : {policy_id}
  Disease    : {disease}
  Bill Amount: ₹{bill}

Follow your instructions carefully and use your tools.
"""

    print(f"\n📋 Processing Claim: {claim_id}")
    print(f"   Policy : {policy_id}")
    print(f"   Disease: {disease}")
    print(f"   Bill   : ₹{bill}")
    print("\n" + "=" * 60)

    # Build and run graph
    graph = build_claim_graph()
    result = graph(task)

    # ── Results Summary ────────────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("   📊 EXECUTION SUMMARY")
    print("=" * 60)
    print(f"Status         : {result.status}")
    print(f"Execution Time : {result.execution_time}ms")
    print(f"Nodes Completed: {result.completed_nodes} / {result.total_nodes}")
    print(f"Token Usage    : {result.accumulated_usage}")

    print("\n── Node Results ──")
    for node in result.execution_order:
        node_result = result.results.get(node.node_id)
        status_icon = "✅" if node_result and node_result.status == Status.COMPLETED else "❌"
        print(f"{status_icon} {node.node_id} ({node_result.execution_time}ms)")
