import json
from strands import tool

# ── helpers ──────────────────────────────────────────────────────────────────

def _load(path: str) -> dict:
    with open(path) as f:
        return json.load(f)

# ── Policy Tools ──────────────────────────────────────────────────────────────

@tool
def get_policy_details(policy_id: str) -> str:
    """
    Fetch policy details from the database using policy_id.
    Returns holder name, insurance name, status, expiry date, and covered diseases.
    Always call this FIRST before any other check.
    """
    data = _load("mock_policies.json")
    for p in data["policies"]:
        if p["policy_id"] == policy_id:
            return f"""
Policy Found:
  Policy ID      : {p['policy_id']}
  Holder Name    : {p['holder_name']}
  Insurance      : {p['insurance_name']}
  Status         : {p['status']}
  Expiry Date    : {p['expiry_date']}
  Sum Insured    : ₹{p['sum_insured']}
  Covered Diseases: {', '.join(p['covered_diseases'])}
"""
    return f"ERROR: Policy ID {policy_id} not found in database."


@tool
def check_disease_coverage(disease: str) -> str:
    """
    Check if a disease is covered under company policy and return coverage percentage and max amount.
    Call this after confirming policy is active.
    """
    data = _load("mock_company_policy.json")
    rules = data["coverage_rules"]
    disease_lower = disease.lower()

    if disease_lower in rules:
        rule = rules[disease_lower]
        if rule["covered"]:
            return f"""
Disease Coverage:
  Disease             : {disease}
  Covered             : Yes
  Coverage Percentage : {rule['coverage_percentage']}%
  Max Coverage Amount : ₹{rule['max_coverage_amount']}
  Waiting Period      : {rule['waiting_period_days']} days
"""
        else:
            return f"NOT COVERED: {disease} is excluded from the company policy."
    return f"NOT FOUND: {disease} is not listed in the company policy."


# ── Document Tools ─────────────────────────────────────────────────────────────

@tool
def get_claim_documents(claim_id: str) -> str:
    """
    Retrieve submitted documents for a claim from the database.
    Call this in the document checker agent to validate all submitted proofs.
    """
    data = _load("mock_documents.json")
    docs = data["documents"]

    if docs["claim_id"] != claim_id:
        return f"ERROR: No documents found for claim ID {claim_id}."

    return f"""
Documents for Claim {claim_id}:
  Patient Name          : {docs['patient_name']}
  Hospital              : {docs['hospital_name']}
  Approved Network      : {docs['hospital_approved_network']}
  Patient ID Proof      : Present={docs['patient_id_proof']['present']}, Verified={docs['patient_id_proof']['verified']}, Matches Holder={docs['patient_id_proof']['matches_policy_holder']}
  Doctor Prescription   : Present={docs['doctor_prescription']['present']}, Registered Doctor={docs['doctor_prescription']['registered_doctor']}
  Hospital Bills        : Present={docs['hospital_bills']['present']}, Amount=₹{docs['hospital_bills']['total_amount']}, Tampered={docs['hospital_bills']['tampered']}
  Diagnosis Report      : Present={docs['diagnosis_report']['present']}, Disease={docs['diagnosis_report']['disease_confirmed']}
  Discharge Summary     : Present={docs['discharge_summary']['present']}, Verified={docs['discharge_summary']['verified']}
"""


# ── Claim Request Tool ─────────────────────────────────────────────────────────

@tool
def get_claim_request() -> str:
    """
    Read the incoming claim request from the input JSON file.
    Always call this at the very start to get policy_id, disease, and claim details.
    """
    data = _load("mock_claim_request.json")
    req = data["claim_request"]
    return f"""
Claim Request:
  Claim ID            : {req['claim_id']}
  Policy ID           : {req['policy_id']}
  Patient Name        : {req['patient_name']}
  Disease             : {req['disease']}
  Hospital            : {req['hospital_name']}
  Estimated Bill      : ₹{req['estimated_bill_amount']}
  Doctor              : {req['doctor_name']}
  Treatment           : {req['treatment_required']}
"""
